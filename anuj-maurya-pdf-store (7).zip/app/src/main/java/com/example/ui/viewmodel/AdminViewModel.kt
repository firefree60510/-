package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.model.AdminStats
import com.example.data.model.AppSettings
import com.example.data.model.OrderItem
import com.example.data.model.PdfItem
import com.example.data.repository.PdfRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AdminUiState(
    val isLoggedIn: Boolean = false,
    val adminName: String = "Anuj Maurya",
    val isLoading: Boolean = false,
    val loginError: String? = null,
    val stats: AdminStats = AdminStats(),
    val orders: List<OrderItem> = emptyList(),
    val pdfs: List<PdfItem> = emptyList(),
    val selectedTab: Int = 0, // 0 = Orders, 1 = Manage PDFs (Post & Delete), 2 = Settings (QR & Links)
    val selectedFilter: String = "All", // "All", "Pending", "Approved", "Rejected"
    val appSettings: AppSettings = AppSettings(),
    val actionSuccessMessage: String? = null
)

class AdminViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PdfRepository(application)
    private val preferences = AppPreferences(application)

    private val _uiState = MutableStateFlow(
        AdminUiState(
            isLoggedIn = preferences.isAdminLoggedIn,
            adminName = preferences.adminName,
            appSettings = repository.getLocalSettings()
        )
    )
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    init {
        if (_uiState.value.isLoggedIn) {
            loadDashboardData()
        }
    }

    fun selectTab(index: Int) {
        _uiState.update { it.copy(selectedTab = index) }
        if (index == 1) {
            loadPdfs()
        }
    }

    fun login(user: String, pass: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, loginError = null) }
            val result = repository.adminLogin(user, pass)
            if (result.isSuccess) {
                _uiState.update {
                    it.copy(
                        isLoggedIn = true,
                        adminName = preferences.adminName,
                        isLoading = false,
                        loginError = null
                    )
                }
                loadDashboardData()
            } else {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        loginError = result.exceptionOrNull()?.localizedMessage ?: "Invalid credentials"
                    )
                }
            }
        }
    }

    fun logout() {
        preferences.isAdminLoggedIn = false
        _uiState.update {
            it.copy(isLoggedIn = false, loginError = null)
        }
    }

    fun loadDashboardData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, actionSuccessMessage = null) }
            val settingsResult = repository.getSettings()
            val ordersResult = repository.getAdminOrders(_uiState.value.selectedFilter)
            val pdfsResult = repository.getPdfs()

            val (stats, orders) = ordersResult.getOrDefault(Pair(AdminStats(), emptyList()))
            _uiState.update {
                it.copy(
                    isLoading = false,
                    stats = stats,
                    orders = orders,
                    pdfs = pdfsResult.getOrDefault(emptyList()),
                    appSettings = settingsResult.getOrDefault(repository.getLocalSettings())
                )
            }
        }
    }

    fun loadPdfs() {
        viewModelScope.launch {
            val pdfsResult = repository.getPdfs()
            _uiState.update {
                it.copy(pdfs = pdfsResult.getOrDefault(emptyList()))
            }
        }
    }

    fun filterOrders(status: String) {
        _uiState.update { it.copy(selectedFilter = status) }
        viewModelScope.launch {
            val ordersResult = repository.getAdminOrders(status)
            val (stats, orders) = ordersResult.getOrDefault(Pair(_uiState.value.stats, emptyList()))
            _uiState.update { it.copy(stats = stats, orders = orders) }
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: String, message: String?) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            repository.updateAdminOrderStatus(orderId, newStatus, message)
            loadDashboardData()
            _uiState.update {
                it.copy(actionSuccessMessage = "Order $orderId updated to $newStatus")
            }
        }
    }

    // ADMIN: Post New PDF with Front-Page Cover Image
    fun postNewPdf(
        title: String,
        boardClass: String,
        subject: String,
        category: String,
        price: Double,
        originalPrice: Double?,
        description: String,
        pagesCount: Int,
        fileSize: String,
        year: String,
        coverImageUri: Uri?
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            var coverImageUrl: String? = null
            if (coverImageUri != null) {
                try {
                    coverImageUrl = repository.saveCoverImageToInternalStorage(coverImageUri)
                } catch (_: Exception) {}
            }
            val item = PdfItem(
                id = 0L,
                title = title,
                boardClass = boardClass,
                subject = subject,
                category = category,
                price = price,
                originalPrice = originalPrice,
                description = description,
                pagesCount = pagesCount,
                fileSize = fileSize,
                year = year,
                previewImageUrl = coverImageUrl,
                downloadUrl = null,
                isFeatured = true
            )
            repository.addPdf(item)
            val updatedPdfs = repository.getPdfs().getOrDefault(emptyList())
            _uiState.update {
                it.copy(
                    isLoading = false,
                    pdfs = updatedPdfs,
                    actionSuccessMessage = "Post published with front-page cover image!"
                )
            }
        }
    }

    // ADMIN: Delete a PDF (remove fake or unwanted posts)
    fun deletePdf(id: Long, title: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            repository.deletePdf(id)
            val updatedPdfs = repository.getPdfs().getOrDefault(emptyList())
            _uiState.update {
                it.copy(
                    isLoading = false,
                    pdfs = updatedPdfs,
                    actionSuccessMessage = "PDF '$title' deleted successfully!"
                )
            }
        }
    }

    // ADMIN: Save Settings (UPI ID, Name, WhatsApp, YouTube link, Telegram link, Announcement)
    fun saveSettings(
        upiId: String,
        upiName: String,
        announcement: String,
        whatsapp: String,
        youtubeUrl: String,
        telegramUrl: String,
        qrUri: Uri?
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            var savedQrUrl = _uiState.value.appSettings.upiQrUrl
            if (qrUri != null) {
                try {
                    savedQrUrl = repository.saveQrUriToInternalStorage(qrUri)
                } catch (_: Exception) {}
            }
            repository.updateAdminSettings(
                upiId = upiId,
                upiName = upiName,
                announcement = announcement,
                whatsapp = whatsapp,
                youtubeUrl = youtubeUrl,
                telegramUrl = telegramUrl,
                upiQrUrl = savedQrUrl
            )
            val newSettings = repository.getLocalSettings()
            _uiState.update {
                it.copy(
                    isLoading = false,
                    appSettings = newSettings,
                    actionSuccessMessage = "Settings, Social Links & UPI updated successfully!"
                )
            }
        }
    }

    fun clearActionMessage() {
        _uiState.update { it.copy(actionSuccessMessage = null) }
    }
}
