package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.model.AppSettings
import com.example.data.model.OrderResponseData
import com.example.data.model.PdfItem
import com.example.data.repository.PdfRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PaymentUiState(
    val isLoading: Boolean = true,
    val pdf: PdfItem? = null,
    val appSettings: AppSettings = AppSettings(),
    val screenshotUri: Uri? = null,
    val studentName: String = "",
    val whatsappNumber: String = "",
    val utrNumber: String = "",
    val isSubmitting: Boolean = false,
    val submittedOrder: OrderResponseData? = null,
    val errorMessage: String? = null
)

class PaymentViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PdfRepository(application)
    private val preferences = AppPreferences(application)

    private val _uiState = MutableStateFlow(
        PaymentUiState(
            studentName = preferences.studentName,
            whatsappNumber = preferences.whatsappNumber
        )
    )
    val uiState: StateFlow<PaymentUiState> = _uiState.asStateFlow()

    fun loadData(pdfId: Long) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val settingsResult = repository.getSettings()
            val pdfResult = repository.getPdfDetails(pdfId)

            _uiState.update {
                it.copy(
                    isLoading = false,
                    appSettings = settingsResult.getOrDefault(AppSettings()),
                    pdf = pdfResult.getOrNull()
                )
            }
        }
    }

    fun onScreenshotSelected(uri: Uri?) {
        _uiState.update { it.copy(screenshotUri = uri, errorMessage = null) }
    }

    fun onNameChanged(name: String) {
        _uiState.update { it.copy(studentName = name, errorMessage = null) }
    }

    fun onWhatsappChanged(phone: String) {
        _uiState.update { it.copy(whatsappNumber = phone, errorMessage = null) }
    }

    fun onUtrChanged(utr: String) {
        _uiState.update { it.copy(utrNumber = utr, errorMessage = null) }
    }

    fun submitOrder() {
        val state = _uiState.value
        val pdf = state.pdf ?: run {
            _uiState.update { it.copy(errorMessage = "PDF information not loaded") }
            return
        }

        if (state.studentName.trim().isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Please enter your full name") }
            return
        }

        val cleanPhone = state.whatsappNumber.trim().replace("+91", "").replace(" ", "").replace("-", "")
        if (cleanPhone.length < 10) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid 10-digit WhatsApp number") }
            return
        }

        val uri = state.screenshotUri
        if (uri == null) {
            _uiState.update { it.copy(errorMessage = "Please select the payment screenshot from your gallery") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSubmitting = true, errorMessage = null) }
            val result = repository.submitOrder(
                screenshotUri = uri,
                pdfId = pdf.id,
                studentName = state.studentName.trim(),
                whatsappNumber = cleanPhone,
                utrNumber = state.utrNumber.trim().ifEmpty { null }
            )

            if (result.isSuccess) {
                _uiState.update {
                    it.copy(
                        isSubmitting = false,
                        submittedOrder = result.getOrNull()
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isSubmitting = false,
                        errorMessage = result.exceptionOrNull()?.localizedMessage ?: "Failed to submit order. Please try again."
                    )
                }
            }
        }
    }

    fun resetSubmission() {
        _uiState.update { it.copy(submittedOrder = null, errorMessage = null) }
    }
}
