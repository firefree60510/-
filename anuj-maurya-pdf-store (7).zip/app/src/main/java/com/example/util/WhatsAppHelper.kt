package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object WhatsAppHelper {
    /**
     * Cleans phone number and ensures 91 country code prefix without duplicate + or 91
     */
    fun cleanIndianNumber(rawNumber: String): String {
        val digitsOnly = rawNumber.filter { it.isDigit() }
        return when {
            digitsOnly.length == 10 -> "91$digitsOnly"
            digitsOnly.length == 12 && digitsOnly.startsWith("91") -> digitsOnly
            digitsOnly.length > 10 && digitsOnly.startsWith("0") -> "91" + digitsOnly.drop(1)
            else -> digitsOnly
        }
    }

    /**
     * Reliably opens WhatsApp chat with phone number and optional message
     */
    fun openChat(context: Context, rawNumber: String, message: String = "") {
        val cleanedNumber = cleanIndianNumber(rawNumber)
        if (cleanedNumber.length < 10) {
            Toast.makeText(context, "Invalid WhatsApp Number: $rawNumber", Toast.LENGTH_SHORT).show()
            return
        }

        val encodedMsg = if (message.isNotEmpty()) "?text=${Uri.encode(message)}" else ""
        val url = "https://api.whatsapp.com/send?phone=$cleanedNumber$encodedMsg"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        try {
            // Try explicit WhatsApp package first if installed
            val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                setPackage("com.whatsapp")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(waIntent)
        } catch (_: Exception) {
            try {
                // Fallback to default browser or app chooser
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "WhatsApp is not installed on this device", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
