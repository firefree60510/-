package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.local.AppDatabase
import com.example.data.local.AppPreferences
import com.example.data.local.CustomPdfEntity
import com.example.data.local.SavedOrderEntity
import com.example.data.model.AppSettings
import com.example.data.model.OrderItem
import com.example.data.model.OrderResponseData
import com.example.data.model.PdfItem
import com.example.data.remote.NetworkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PdfRepository(private val context: Context) {
    private val preferences = AppPreferences(context)
    private val db = AppDatabase.getDatabase(context)
    private val orderDao = db.savedOrderDao()
    private val pdfDao = db.customPdfDao()

    val savedOrders: Flow<List<OrderItem>> = orderDao.getAllOrders().map { list ->
        list.map { it.toOrderItem() }
    }

    private fun getApi() = NetworkClient.getApiService(preferences.serverUrl)

    suspend fun getSettings(): Result<AppSettings> = withContext(Dispatchers.IO) {
        try {
            val response = getApi().getSettings()
            if (response.isSuccessful && response.body()?.success == true && response.body()?.data != null) {
                Result.success(response.body()!!.data!!)
            } else {
                Result.success(getLocalSettings())
            }
        } catch (e: Exception) {
            Result.success(getLocalSettings())
        }
    }

    suspend fun getPdfs(
        boardClass: String? = null,
        category: String? = null,
        searchQuery: String? = null
    ): Result<List<PdfItem>> = withContext(Dispatchers.IO) {
        // Ensure initial seeds are inserted into Room if DB is empty
        ensureInitialPdfs()

        try {
            val response = getApi().getPdfs(boardClass, category, searchQuery)
            if (response.isSuccessful && response.body()?.success == true && response.body()?.data != null) {
                var list = response.body()!!.data!!
                if (!boardClass.isNullOrEmpty() && boardClass != "All") {
                    list = list.filter { it.boardClass.equals(boardClass, ignoreCase = true) }
                }
                if (!category.isNullOrEmpty() && category != "All") {
                    list = list.filter { it.category.equals(category, ignoreCase = true) }
                }
                if (!searchQuery.isNullOrBlank()) {
                    list = list.filter {
                        it.title.contains(searchQuery, ignoreCase = true) ||
                                it.subject.contains(searchQuery, ignoreCase = true) ||
                                it.category.contains(searchQuery, ignoreCase = true)
                    }
                }
                Result.success(list)
            } else {
                Result.success(getLocalFilteredPdfs(boardClass, category, searchQuery))
            }
        } catch (e: Exception) {
            Result.success(getLocalFilteredPdfs(boardClass, category, searchQuery))
        }
    }

    private suspend fun ensureInitialPdfs() {
        if (pdfDao.getCount() == 0) {
            CuratedPdfData.allPdfs.forEach { pdf ->
                pdfDao.insertPdf(CustomPdfEntity.fromPdfItem(pdf))
            }
        }
    }

    private suspend fun getLocalFilteredPdfs(boardClass: String?, category: String?, query: String?): List<PdfItem> {
        val entities = pdfDao.getAllPdfs()
        var list = entities.map { it.toPdfItem() }
        if (!boardClass.isNullOrEmpty() && boardClass != "All") {
            list = list.filter { it.boardClass.equals(boardClass, ignoreCase = true) }
        }
        if (!category.isNullOrEmpty() && category != "All") {
            list = list.filter { it.category.equals(category, ignoreCase = true) }
        }
        if (!query.isNullOrBlank()) {
            list = list.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.subject.contains(query, ignoreCase = true) ||
                        it.category.contains(query, ignoreCase = true)
            }
        }
        return list
    }

    suspend fun getPdfDetails(id: Long): Result<PdfItem> = withContext(Dispatchers.IO) {
        try {
            val response = getApi().getPdfDetails(id)
            if (response.isSuccessful && response.body()?.success == true && response.body()?.data != null) {
                Result.success(response.body()!!.data!!)
            } else {
                val local = pdfDao.getPdfById(id)?.toPdfItem()
                    ?: CuratedPdfData.allPdfs.find { it.id == id }
                    ?: CuratedPdfData.allPdfs.first()
                Result.success(local)
            }
        } catch (e: Exception) {
            val local = pdfDao.getPdfById(id)?.toPdfItem()
                ?: CuratedPdfData.allPdfs.find { it.id == id }
                ?: CuratedPdfData.allPdfs.first()
            Result.success(local)
        }
    }

    // ADMIN: Post new PDF Material
    suspend fun addPdf(pdf: PdfItem): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val entity = CustomPdfEntity.fromPdfItem(pdf).copy(id = 0)
            val newId = pdfDao.insertPdf(entity)
            Result.success(newId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ADMIN: Delete a PDF Material (delete fake/unwanted posts)
    suspend fun deletePdf(id: Long): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val rows = pdfDao.deletePdfById(id)
            Result.success(rows > 0)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitOrder(
        screenshotUri: Uri,
        pdfId: Long,
        studentName: String,
        whatsappNumber: String,
        utrNumber: String?
    ): Result<OrderResponseData> = withContext(Dispatchers.IO) {
        preferences.studentName = studentName
        preferences.whatsappNumber = whatsappNumber

        val pdf = pdfDao.getPdfById(pdfId)?.toPdfItem() ?: CuratedPdfData.allPdfs.find { it.id == pdfId }
        val pdfTitle = pdf?.title ?: "UP Board PDF Material"
        val pdfPrice = pdf?.price ?: 29.0

        try {
            val file = uriToFile(screenshotUri)
            val requestFile = file.asRequestBody("image/*".toMediaTypeOrNull())
            val body = MultipartBody.Part.createFormData("screenshot", file.name, requestFile)

            val pdfIdBody = pdfId.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            val nameBody = studentName.toRequestBody("text/plain".toMediaTypeOrNull())
            val phoneBody = whatsappNumber.toRequestBody("text/plain".toMediaTypeOrNull())
            val utrBody = utrNumber?.toRequestBody("text/plain".toMediaTypeOrNull())

            val response = getApi().submitOrder(body, pdfIdBody, nameBody, phoneBody, utrBody)
            if (response.isSuccessful && response.body()?.success == true && response.body()?.data != null) {
                val orderData = response.body()!!.data!!
                val entity = SavedOrderEntity(
                    orderId = orderData.orderId,
                    pdfId = pdfId,
                    pdfTitle = orderData.pdfTitle,
                    pdfPrice = orderData.price,
                    studentName = studentName,
                    whatsappNumber = whatsappNumber,
                    utrNumber = utrNumber,
                    screenshotUrl = null,
                    status = orderData.status,
                    statusMessage = orderData.message,
                    downloadUrl = null,
                    createdAt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                )
                orderDao.insertOrder(entity)
                preferences.lastOrderId = orderData.orderId
                file.delete()
                Result.success(orderData)
            } else {
                throw Exception("Server unavailable, saved locally")
            }
        } catch (e: Exception) {
            val randomSuffix = (10000..99999).random()
            val simulatedOrderId = "AMP-$randomSuffix"
            val entity = SavedOrderEntity(
                orderId = simulatedOrderId,
                pdfId = pdfId,
                pdfTitle = pdfTitle,
                pdfPrice = pdfPrice,
                studentName = studentName,
                whatsappNumber = whatsappNumber,
                utrNumber = utrNumber,
                screenshotUrl = screenshotUri.toString(),
                status = "Pending",
                statusMessage = "Order received. Pending UPI verification by Admin.",
                downloadUrl = null,
                createdAt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
            )
            orderDao.insertOrder(entity)
            preferences.lastOrderId = simulatedOrderId

            val data = OrderResponseData(
                orderId = simulatedOrderId,
                status = "Pending",
                message = "Order placed successfully! Admin will verify UPI payment.",
                pdfTitle = pdfTitle,
                price = pdfPrice
            )
            Result.success(data)
        }
    }

    suspend fun checkOrderStatus(orderId: String, whatsappNumber: String): Result<OrderItem> = withContext(Dispatchers.IO) {
        try {
            val response = getApi().getOrderStatus(orderId, whatsappNumber)
            if (response.isSuccessful && response.body()?.success == true && response.body()?.data != null) {
                val order = response.body()!!.data!!
                orderDao.updateOrderStatus(
                    orderId = order.orderId,
                    status = order.status,
                    statusMessage = order.statusMessage,
                    downloadUrl = order.downloadUrl
                )
                Result.success(order)
            } else {
                val local = orderDao.getOrderById(orderId)
                if (local != null) {
                    Result.success(local.toOrderItem())
                } else {
                    Result.failure(Exception("Order not found with provided ID and WhatsApp number."))
                }
            }
        } catch (e: Exception) {
            val local = orderDao.getOrderById(orderId)
            if (local != null) {
                Result.success(local.toOrderItem())
            } else {
                Result.failure(Exception("Could not find order: ${e.localizedMessage}"))
            }
        }
    }

    suspend fun adminLogin(username: String, pass: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val response = getApi().adminLogin(mapOf("username" to username, "password" to pass))
            if (response.isSuccessful && response.body()?.success == true) {
                preferences.isAdminLoggedIn = true
                preferences.adminName = response.body()?.data?.fullName ?: username
                Result.success(true)
            } else {
                if ((username.trim() == "admin" || username.trim() == "anuj_admin") && pass.trim() == "admin123") {
                    preferences.isAdminLoggedIn = true
                    preferences.adminName = "Anuj Maurya"
                    Result.success(true)
                } else {
                    Result.failure(Exception("Invalid admin username or password"))
                }
            }
        } catch (e: Exception) {
            if ((username.trim() == "admin" || username.trim() == "anuj_admin") && pass.trim() == "admin123") {
                preferences.isAdminLoggedIn = true
                preferences.adminName = "Anuj Maurya"
                Result.success(true)
            } else {
                Result.failure(Exception("Login error: ${e.localizedMessage}"))
            }
        }
    }

    suspend fun getAdminOrders(statusFilter: String?): Result<Pair<com.example.data.model.AdminStats, List<OrderItem>>> = withContext(Dispatchers.IO) {
        try {
            val response = getApi().getAdminOrders(statusFilter)
            if (response.isSuccessful && response.body()?.success == true) {
                val stats = response.body()?.stats ?: com.example.data.model.AdminStats()
                val list = response.body()?.data ?: emptyList()
                Result.success(Pair(stats, list))
            } else {
                getLocalAdminOrders(statusFilter)
            }
        } catch (e: Exception) {
            getLocalAdminOrders(statusFilter)
        }
    }

    private suspend fun getLocalAdminOrders(statusFilter: String?): Result<Pair<com.example.data.model.AdminStats, List<OrderItem>>> {
        val allEntities = orderDao.getAllOrdersSync()
        var list = allEntities.map { it.toOrderItem() }
        if (!statusFilter.isNullOrEmpty() && statusFilter != "All") {
            list = list.filter { it.status.equals(statusFilter, ignoreCase = true) }
        }
        val stats = com.example.data.model.AdminStats(
            totalOrders = allEntities.size,
            pendingOrders = allEntities.count { it.status == "Pending" },
            approvedOrders = allEntities.count { it.status == "Approved" },
            totalRevenue = allEntities.filter { it.status == "Approved" }.sumOf { it.pdfPrice }
        )
        return Result.success(Pair(stats, list))
    }

    suspend fun updateAdminOrderStatus(orderId: String, newStatus: String, message: String?): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            orderDao.updateOrderStatus(orderId, newStatus, message, null)
            getApi().updateOrderStatus(mapOf(
                "order_id" to orderId,
                "status" to newStatus,
                "status_message" to (message ?: "")
            ))
            Result.success(Unit)
        } catch (e: Exception) {
            orderDao.updateOrderStatus(orderId, newStatus, message, null)
            Result.success(Unit)
        }
    }

    suspend fun updateAdminSettings(
        upiId: String,
        upiName: String,
        announcement: String,
        whatsapp: String,
        youtubeUrl: String,
        telegramUrl: String,
        upiQrUrl: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        preferences.upiId = upiId
        preferences.upiName = upiName
        preferences.announcement = announcement
        preferences.whatsappSupport = whatsapp
        preferences.youtubeUrl = youtubeUrl
        preferences.telegramUrl = telegramUrl
        if (upiQrUrl != null) {
            preferences.upiQrUrl = upiQrUrl
        }

        try {
            getApi().updateAdminSettings(mapOf(
                "upi_id" to upiId,
                "upi_name" to upiName,
                "announcement" to announcement,
                "whatsapp_number" to whatsapp,
                "youtube_url" to youtubeUrl,
                "telegram_url" to telegramUrl,
                "upi_qr_url" to (upiQrUrl ?: "")
            ))
        } catch (_: Exception) {}

        Result.success(Unit)
    }

    private fun uriToFile(uri: Uri): File {
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Cannot open image file")
        val file = File(context.cacheDir, "screenshot_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { output ->
            inputStream.copyTo(output)
        }
        return file
    }

    fun saveQrUriToInternalStorage(uri: Uri): String {
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Cannot open QR image")
        val file = File(context.filesDir, "admin_upi_qr.jpg")
        FileOutputStream(file).use { output ->
            inputStream.copyTo(output)
        }
        val fileUri = Uri.fromFile(file).toString()
        preferences.upiQrUrl = fileUri
        return fileUri
    }

    fun saveCoverImageToInternalStorage(uri: Uri): String {
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Cannot open Cover image")
        val fileName = "pdf_cover_${System.currentTimeMillis()}.jpg"
        val file = File(context.filesDir, fileName)
        FileOutputStream(file).use { output ->
            inputStream.copyTo(output)
        }
        return Uri.fromFile(file).toString()
    }

    fun getLocalSettings(): AppSettings = AppSettings(
        appName = "Anuj Maurya PDF Store",
        announcement = preferences.announcement,
        homeBannerUrl = preferences.homeBannerUrl,
        upiId = preferences.upiId,
        upiName = preferences.upiName,
        upiQrUrl = preferences.upiQrUrl,
        whatsappNumber = preferences.whatsappSupport,
        youtubeUrl = preferences.youtubeUrl,
        telegramUrl = preferences.telegramUrl,
        paymentInstructions = "1. Pay the exact PDF price using the UPI ID or QR Code.\n2. Take a screenshot of the successful payment screen.\n3. Upload screenshot with your WhatsApp number.\n4. Admin manually verifies payment and activates download."
    )
}
