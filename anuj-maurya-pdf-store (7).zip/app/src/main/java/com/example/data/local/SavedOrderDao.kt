package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedOrderDao {
    @Query("SELECT * FROM saved_orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<SavedOrderEntity>>

    @Query("SELECT * FROM saved_orders ORDER BY createdAt DESC")
    suspend fun getAllOrdersSync(): List<SavedOrderEntity>

    @Query("SELECT * FROM saved_orders WHERE orderId = :orderId LIMIT 1")
    suspend fun getOrderById(orderId: String): SavedOrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: SavedOrderEntity)

    @Query("UPDATE saved_orders SET status = :status, statusMessage = :statusMessage, downloadUrl = :downloadUrl WHERE orderId = :orderId")
    suspend fun updateOrderStatus(orderId: String, status: String, statusMessage: String?, downloadUrl: String?)

    @Query("DELETE FROM saved_orders WHERE orderId = :orderId")
    suspend fun deleteOrder(orderId: String)
}
