package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class PdfItem(
    @Json(name = "id") val id: Long,
    @Json(name = "title") val title: String,
    @Json(name = "board_class") val boardClass: String, // "Class 9" or "Class 10"
    @Json(name = "subject") val subject: String,       // "Mathematics", "Science", "Hindi", etc.
    @Json(name = "category") val category: String,     // "Notes", "Important Papers", "Model Papers", "Previous Year Papers", "Important Questions"
    @Json(name = "price") val price: Double,
    @Json(name = "original_price") val originalPrice: Double? = null,
    @Json(name = "description") val description: String? = null,
    @Json(name = "preview_image_url") val previewImageUrl: String? = null,
    @Json(name = "pages_count") val pagesCount: Int = 0,
    @Json(name = "file_size") val fileSize: String? = null,
    @Json(name = "year") val year: String? = null,
    @Json(name = "is_available") val isAvailable: Boolean = true,
    @Json(name = "is_featured") val isFeatured: Boolean = false,
    @Json(name = "sample_preview_url") val samplePreviewUrl: String? = null,
    @Json(name = "download_url") val downloadUrl: String? = null
)

@JsonClass(generateAdapter = true)
data class AppSettings(
    @Json(name = "app_name") val appName: String = "Anuj Maurya PDF Store",
    @Json(name = "announcement") val announcement: String = "UP Board Exam 2025-26 Special: Class 9 & 10 Model Papers & Important Notes are now available!",
    @Json(name = "home_banner_url") val homeBannerUrl: String? = null,
    @Json(name = "upi_id") val upiId: String = "anujmaurya@upi",
    @Json(name = "upi_name") val upiName: String = "Anuj Maurya",
    @Json(name = "upi_qr_url") val upiQrUrl: String? = null,
    @Json(name = "whatsapp_number") val whatsappNumber: String = "919876543210",
    @Json(name = "youtube_url") val youtubeUrl: String = "https://youtube.com/@anujmauryapdf",
    @Json(name = "telegram_url") val telegramUrl: String = "https://t.me/anujmauryapdf",
    @Json(name = "payment_instructions") val paymentInstructions: String = "1. Pay exact amount using UPI ID or QR Code\n2. Take a screenshot of the successful transaction\n3. Upload screenshot with your WhatsApp number\n4. Admin will verify and activate your PDF within 1-2 hours."
)

@JsonClass(generateAdapter = true)
data class OrderItem(
    @Json(name = "order_id") val orderId: String,
    @Json(name = "pdf_id") val pdfId: Long,
    @Json(name = "pdf_title") val pdfTitle: String,
    @Json(name = "pdf_price") val pdfPrice: Double,
    @Json(name = "student_name") val studentName: String,
    @Json(name = "whatsapp_number") val whatsappNumber: String,
    @Json(name = "utr_number") val utrNumber: String? = null,
    @Json(name = "screenshot_url") val screenshotUrl: String? = null,
    @Json(name = "status") val status: String = "Pending", // "Pending", "Approved", "Rejected", "Delivered"
    @Json(name = "status_message") val statusMessage: String? = null,
    @Json(name = "download_url") val downloadUrl: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class ApiResponse<T>(
    @Json(name = "success") val success: Boolean,
    @Json(name = "message") val message: String? = null,
    @Json(name = "data") val data: T? = null,
    @Json(name = "error") val error: String? = null
)

@JsonClass(generateAdapter = true)
data class OrderResponseData(
    @Json(name = "order_id") val orderId: String,
    @Json(name = "status") val status: String,
    @Json(name = "message") val message: String,
    @Json(name = "pdf_title") val pdfTitle: String,
    @Json(name = "price") val price: Double
)

@JsonClass(generateAdapter = true)
data class AdminLoginResponse(
    @Json(name = "token") val token: String,
    @Json(name = "username") val username: String,
    @Json(name = "full_name") val fullName: String
)

@JsonClass(generateAdapter = true)
data class AdminStats(
    @Json(name = "total_orders") val totalOrders: Int = 0,
    @Json(name = "pending_orders") val pendingOrders: Int = 0,
    @Json(name = "approved_orders") val approvedOrders: Int = 0,
    @Json(name = "total_revenue") val totalRevenue: Double = 0.0
)

@JsonClass(generateAdapter = true)
data class AdminOrdersResponse(
    @Json(name = "success") val success: Boolean,
    @Json(name = "stats") val stats: AdminStats? = null,
    @Json(name = "data") val data: List<OrderItem>? = null,
    @Json(name = "message") val message: String? = null
)

