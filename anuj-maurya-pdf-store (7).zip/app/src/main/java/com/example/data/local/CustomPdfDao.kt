package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomPdfDao {
    @Query("SELECT * FROM custom_pdfs ORDER BY id DESC")
    fun getAllPdfsFlow(): Flow<List<CustomPdfEntity>>

    @Query("SELECT * FROM custom_pdfs ORDER BY id DESC")
    suspend fun getAllPdfs(): List<CustomPdfEntity>

    @Query("SELECT * FROM custom_pdfs WHERE id = :id LIMIT 1")
    suspend fun getPdfById(id: Long): CustomPdfEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPdf(pdf: CustomPdfEntity): Long

    @Update
    suspend fun updatePdf(pdf: CustomPdfEntity)

    @Query("DELETE FROM custom_pdfs WHERE id = :id")
    suspend fun deletePdfById(id: Long): Int

    @Query("DELETE FROM custom_pdfs")
    suspend fun deleteAll(): Int

    @Query("SELECT COUNT(*) FROM custom_pdfs")
    suspend fun getCount(): Int
}
