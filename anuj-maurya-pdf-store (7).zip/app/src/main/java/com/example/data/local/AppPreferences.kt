package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("anuj_pdf_store_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_SERVER_URL = "key_server_url"
        private const val KEY_STUDENT_NAME = "key_student_name"
        private const val KEY_WHATSAPP = "key_whatsapp"
        private const val KEY_LAST_ORDER_ID = "key_last_order_id"
        private const val KEY_ADMIN_LOGGED_IN = "key_admin_logged_in"
        private const val KEY_ADMIN_NAME = "key_admin_name"

        // App Settings fields
        private const val KEY_APP_NAME = "key_app_name"
        private const val KEY_ANNOUNCEMENT = "key_announcement"
        private const val KEY_UPI_ID = "key_upi_id"
        private const val KEY_UPI_NAME = "key_upi_name"
        private const val KEY_UPI_QR_URL = "key_upi_qr_url"
        private const val KEY_WHATSAPP_SUPPORT = "key_whatsapp_support"
        private const val KEY_YOUTUBE_URL = "key_youtube_url"
        private const val KEY_TELEGRAM_URL = "key_telegram_url"
        private const val KEY_HOME_BANNER_URL = "key_home_banner_url"

        const val DEFAULT_SERVER_URL = "https://anujmaurya.com/api/"
    }

    var isAdminLoggedIn: Boolean
        get() = prefs.getBoolean(KEY_ADMIN_LOGGED_IN, false)
        set(value) = prefs.edit().putBoolean(KEY_ADMIN_LOGGED_IN, value).apply()

    var adminName: String
        get() = prefs.getString(KEY_ADMIN_NAME, "Anuj Maurya") ?: "Anuj Maurya"
        set(value) = prefs.edit().putString(KEY_ADMIN_NAME, value).apply()

    var serverUrl: String
        get() = prefs.getString(KEY_SERVER_URL, DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL
        set(value) = prefs.edit().putString(KEY_SERVER_URL, value.trim().let {
            if (it.endsWith("/")) it else "$it/"
        }).apply()

    var studentName: String
        get() = prefs.getString(KEY_STUDENT_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_STUDENT_NAME, value).apply()

    var whatsappNumber: String
        get() = prefs.getString(KEY_WHATSAPP, "") ?: ""
        set(value) = prefs.edit().putString(KEY_WHATSAPP, value).apply()

    var lastOrderId: String
        get() = prefs.getString(KEY_LAST_ORDER_ID, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_ORDER_ID, value).apply()

    // Persistent Local App Settings
    var upiId: String
        get() = prefs.getString(KEY_UPI_ID, "anujmaurya@upi") ?: "anujmaurya@upi"
        set(value) = prefs.edit().putString(KEY_UPI_ID, value).apply()

    var upiName: String
        get() = prefs.getString(KEY_UPI_NAME, "Anuj Maurya") ?: "Anuj Maurya"
        set(value) = prefs.edit().putString(KEY_UPI_NAME, value).apply()

    var upiQrUrl: String?
        get() = prefs.getString(KEY_UPI_QR_URL, null)
        set(value) = prefs.edit().putString(KEY_UPI_QR_URL, value).apply()

    var whatsappSupport: String
        get() = prefs.getString(KEY_WHATSAPP_SUPPORT, "919876543210") ?: "919876543210"
        set(value) = prefs.edit().putString(KEY_WHATSAPP_SUPPORT, value).apply()

    var youtubeUrl: String
        get() = prefs.getString(KEY_YOUTUBE_URL, "https://youtube.com/@anujmauryapdf") ?: "https://youtube.com/@anujmauryapdf"
        set(value) = prefs.edit().putString(KEY_YOUTUBE_URL, value).apply()

    var telegramUrl: String
        get() = prefs.getString(KEY_TELEGRAM_URL, "https://t.me/anujmauryapdf") ?: "https://t.me/anujmauryapdf"
        set(value) = prefs.edit().putString(KEY_TELEGRAM_URL, value).apply()

    var announcement: String
        get() = prefs.getString(KEY_ANNOUNCEMENT, "UP Board Exam Special: Class 9 & 10 Model Papers & Important Notes are available!")
            ?: "UP Board Exam Special: Class 9 & 10 Model Papers & Important Notes are available!"
        set(value) = prefs.edit().putString(KEY_ANNOUNCEMENT, value).apply()

    var homeBannerUrl: String?
        get() = prefs.getString(KEY_HOME_BANNER_URL, null)
        set(value) = prefs.edit().putString(KEY_HOME_BANNER_URL, value).apply()
}
