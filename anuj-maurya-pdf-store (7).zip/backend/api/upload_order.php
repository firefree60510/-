<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=UTF-8');

// Ensure request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse([
        'success' => false,
        'message' => 'Invalid request method. POST required.'
    ], 405);
}

// 1. Validate Form Inputs
$pdfId          = isset($_POST['pdf_id']) ? (int)$_POST['pdf_id'] : 0;
$studentName    = isset($_POST['student_name']) ? trim($_POST['student_name']) : '';
$whatsappNumber = isset($_POST['whatsapp_number']) ? trim($_POST['whatsapp_number']) : '';
$utrNumber      = isset($_POST['utr_number']) ? trim($_POST['utr_number']) : null;

if ($pdfId <= 0) {
    sendJsonResponse(['success' => false, 'message' => 'Please provide a valid PDF ID.'], 400);
}

if (empty($studentName)) {
    sendJsonResponse(['success' => false, 'message' => 'Student name is required.'], 400);
}

// Sanitize phone (only digits)
$cleanPhone = preg_replace('/[^0-9]/', '', $whatsappNumber);
if (strlen($cleanPhone) < 10) {
    sendJsonResponse(['success' => false, 'message' => 'A valid 10-digit WhatsApp number is required.'], 400);
}

// 2. Validate Screenshot File Upload
if (!isset($_FILES['screenshot']) || $_FILES['screenshot']['error'] !== UPLOAD_ERR_OK) {
    $uploadError = isset($_FILES['screenshot']['error']) ? $_FILES['screenshot']['error'] : 'No file uploaded';
    sendJsonResponse([
        'success' => false,
        'message' => 'Screenshot file upload failed. Error code: ' . $uploadError
    ], 400);
}

$fileTmpPath   = $_FILES['screenshot']['tmp_name'];
$fileName      = $_FILES['screenshot']['name'];
$fileSize      = $_FILES['screenshot']['size'];
$fileType      = $_FILES['screenshot']['type'];

// Max 10MB limit for screenshot
$maxFileSize = 10 * 1024 * 1024;
if ($fileSize > $maxFileSize) {
    sendJsonResponse([
        'success' => false,
        'message' => 'Screenshot size exceeds 10MB limit. Please upload a smaller image.'
    ], 400);
}

// Allowed MIME types
$allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $fileTmpPath);
finfo_close($finfo);

if (!in_array($mimeType, $allowedMimes)) {
    sendJsonResponse([
        'success' => false,
        'message' => 'Invalid file type. Only JPG, PNG, and WebP images are accepted.'
    ], 400);
}

// 3. Security Rule: Retrieve PDF Price and Title directly from DB (Never trust client price!)
$db = getDbConnection();
$pdfStmt = $db->prepare("SELECT `id`, `title`, `price`, `is_available` FROM `pdfs` WHERE `id` = :id LIMIT 1");
$pdfStmt->execute([':id' => $pdfId]);
$pdfRecord = $pdfStmt->fetch();

if (!$pdfRecord || !$pdfRecord['is_available']) {
    sendJsonResponse([
        'success' => false,
        'message' => 'The requested PDF material is not available for purchase.'
    ], 404);
}

$officialPrice = (float)$pdfRecord['price'];
$officialTitle = $pdfRecord['title'];

// 4. Upload Screenshot to ImgBB using server-side secret API Key
$imgBbApiKey = IMG_BB_API_KEY;

if (empty($imgBbApiKey) || $imgBbApiKey === 'PUT_MY_IMGBB_API_KEY_HERE') {
    // If user has not yet configured ImgBB API key, save locally on server as fallback
    $uploadDir = __DIR__ . '/../uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    $localFileName = 'screenshot_' . time() . '_' . bin2hex(random_bytes(6)) . '.jpg';
    $targetPath = $uploadDir . $localFileName;
    move_uploaded_file($fileTmpPath, $targetPath);
    $screenshotUrl = BASE_URL . 'uploads/' . $localFileName;
    $deleteUrl = null;
} else {
    // Perform ImgBB API multipart upload
    $fileData = file_get_contents($fileTmpPath);
    $base64Image = base64_encode($fileData);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.imgbb.com/1/upload');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_POSTFIELDS, [
        'key' => $imgBbApiKey,
        'image' => $base64Image,
        'name' => 'order_' . time() . '_' . $cleanPhone
    ]);

    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curlError || $httpCode !== 200) {
        sendJsonResponse([
            'success' => false,
            'message' => 'ImgBB upload failed: ' . ($curlError ?: 'HTTP Status ' . $httpCode) . '. Order was not placed.'
        ], 502);
    }

    $imgBbData = json_decode($response, true);
    if (!isset($imgBbData['success']) || !$imgBbData['success'] || empty($imgBbData['data']['url'])) {
        sendJsonResponse([
            'success' => false,
            'message' => 'ImgBB API responded with an error. Order was not placed.'
        ], 502);
    }

    $screenshotUrl = $imgBbData['data']['url'];
    $deleteUrl = isset($imgBbData['data']['delete_url']) ? $imgBbData['data']['delete_url'] : null;
}

// 5. Generate Unique Order ID (Format: AMP-XXXXX)
$uniqueOrderId = 'AMP-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 5)) . mt_rand(10, 99);

// 6. Save Order in MySQL Database
try {
    $insertStmt = $db->prepare(
        "INSERT INTO `orders` 
         (`order_id`, `pdf_id`, `pdf_title`, `pdf_price`, `student_name`, `whatsapp_number`, `utr_number`, `screenshot_url`, `screenshot_delete_url`, `status`, `status_message`) 
         VALUES 
         (:order_id, :pdf_id, :pdf_title, :pdf_price, :student_name, :whatsapp_number, :utr_number, :screenshot_url, :screenshot_delete_url, 'Pending', 'Order received. Pending manual UPI verification by Admin.')"
    );

    $insertStmt->execute([
        ':order_id'              => $uniqueOrderId,
        ':pdf_id'                => $pdfId,
        ':pdf_title'             => $officialTitle,
        ':pdf_price'             => $officialPrice,
        ':student_name'          => $studentName,
        ':whatsapp_number'       => $cleanPhone,
        ':utr_number'            => $utrNumber,
        ':screenshot_url'        => $screenshotUrl,
        ':screenshot_delete_url' => $deleteUrl // Secret: never sent back to student
    ]);

    // 7. Return Order Confirmation Response
    sendJsonResponse([
        'success' => true,
        'message' => 'Order submitted successfully! Please allow 1-2 hours for manual UPI payment verification.',
        'data' => [
            'order_id'   => $uniqueOrderId,
            'status'     => 'Pending',
            'pdf_title'  => $officialTitle,
            'price'      => $officialPrice,
            'message'    => 'Order received. Pending manual UPI verification by Admin.'
        ]
    ], 201);

} catch (Exception $e) {
    sendJsonResponse([
        'success' => false,
        'message' => 'Database error while recording order: ' . $e->getMessage()
    ], 500);
}
