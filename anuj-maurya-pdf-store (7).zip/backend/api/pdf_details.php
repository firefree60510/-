<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=UTF-8');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    sendJsonResponse([
        'success' => false,
        'message' => 'Invalid PDF ID'
    ], 400);
}

try {
    $db = getDbConnection();
    $stmt = $db->prepare("SELECT `id`, `title`, `board_class`, `subject`, `category`, `price`, 
                                 `original_price`, `description`, `preview_image_url`, `pages_count`, 
                                 `file_size`, `year`, `is_available`, `is_featured`, `sample_preview_url` 
                          FROM `pdfs` 
                          WHERE `id` = :id AND `is_available` = 1 
                          LIMIT 1");
    $stmt->execute([':id' => $id]);
    $pdf = $stmt->fetch();

    if (!$pdf) {
        sendJsonResponse([
            'success' => false,
            'message' => 'PDF material not found or unavailable'
        ], 404);
    }

    sendJsonResponse([
        'success' => true,
        'data' => [
            'id' => (int)$pdf['id'],
            'title' => $pdf['title'],
            'board_class' => $pdf['board_class'],
            'subject' => $pdf['subject'],
            'category' => $pdf['category'],
            'price' => (float)$pdf['price'],
            'original_price' => $pdf['original_price'] !== null ? (float)$pdf['original_price'] : null,
            'description' => $pdf['description'],
            'preview_image_url' => $pdf['preview_image_url'],
            'pages_count' => (int)$pdf['pages_count'],
            'file_size' => $pdf['file_size'],
            'year' => $pdf['year'],
            'is_available' => (bool)$pdf['is_available'],
            'is_featured' => (bool)$pdf['is_featured'],
            'sample_preview_url' => $pdf['sample_preview_url'],
            'download_url' => null // Security: download_url is withheld until payment verification
        ]
    ]);

} catch (Exception $e) {
    sendJsonResponse([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ], 500);
}
